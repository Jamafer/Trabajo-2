print("Welcome to OnlineIDE Pro!")
print("Start coding in Python...")
# Desafío 3: Convertidor de temperaturas

# Solicitar al usuario la temperatura en Celsius
celsius = float(input("Ingrese la temperatura en °C: "))

# Conversiones
fahrenheit = (celsius * 9/5) + 32
kelvin     = celsius + 273.15

# Mostrar resultados
print(f"{celsius:.2f} °C equivalen a {fahrenheit:.2f} °F")
print(f"{celsius:.2f} °C equivalen a {kelvin:.2f} K")